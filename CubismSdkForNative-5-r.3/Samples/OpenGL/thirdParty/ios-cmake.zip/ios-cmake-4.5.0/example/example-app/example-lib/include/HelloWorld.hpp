#pragma once
#include <string>

class HelloWorld
{
public:
  std::string helloWorld();
};
