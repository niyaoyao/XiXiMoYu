#include <iostream>

#include "HelloWorld.hpp"

int main(int argc, char** argv)
{
    HelloWorld hw;
    std::cout << hw.helloWorld() << std::endl;
}